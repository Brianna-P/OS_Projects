# Semaphores - Intro to OS Programming Project 2
The project is a brief example of shared memory can be protected with semaphores when multiple processes are attempting to access said shared memory.

## Table of contents
"OPsP2.c" - The executable file that contains all of the code for the project

"readme.md" - A non-executable file describing the program itself

## Usage
To compile: 
gcc -o OPsP2.exe OPsP2.c

To run:
./OPsP2.exe